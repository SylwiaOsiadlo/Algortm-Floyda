#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <malloc.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h> // Plik nagłówkowy dodający czcionki


const int MAXINT = 2147483647; // MAX WARTOSC - PLUS NIESKONCZONOSC

// Zmienne globalne

int tab[5][13], tab_2[5][13]; // MACIERZE KOSZTOW ORAZ POPRZEDNIKOW
int n, m;     // ZMIENNE DLA LICZBY WIERZCHOLKOW ORAZ KRAWEDZI

// FUNKCJA WYZNACZA KOSZTY ORAZ MINIMALNE SCIEZKI W GRAFIE WAZONYM


int FloydWarshall( )
{
  int i, j, k, w;

  for( k = 0; k < n; k++ )
    for( i = 0; i < n; i++ )
      for( j = 0; j < n; j++ )
      {
        if( ( tab [ i ][ k ] == MAXINT ) || ( tab [ k ][ j ] == MAXINT ) ) continue;
        w = tab [ i ][ k ] + tab [ k ][ j ];
        if( tab [ i ][ j ] > w )
        {
          tab [ i ][ j ] = w;
          tab_2 [ i ][ j ] = tab_2 [ k ][ j ];
        }
      }
  for( i = 0; i < n; i++ )
    if( tab [ i ][ i ] < 0 ) return 0; // KONTROLA UJEMNEGO CYKLU
  return 1;
}

//  ODTWARZANIE NAJKROTSZEJ SCIEZKI Z MACIERZEY POPRZEDNIKOW TAB_2(REKURENCYJNIE)

void FWPath ( int i, int j )
{
  if( i == j ) printf("%d ",i);
  else if( tab_2 [ i ][ j ] == -1 ) printf( "NO PATH");
  else
  {
    FWPath ( i, tab_2 [ i ][ j ] );
    printf("%d ", j);
  }
}


// PROGRAM GLOWNY

int main( )
{


// **********************
// ***** ALLEGRO <3 *****
// **********************

// al_init - inicjalizacja biblioteki
    if( !al_init() ) //obslga bledu
    {
        fprintf( stderr, "Nie zainicjalizowano biblioteki allegro :( \n" );
        return - 1;
    }
// definiowanie wsk do obiektow
    ALLEGRO_DISPLAY * okno = al_create_display( 640, 480); //Tworzenie okna 640x480
    ALLEGRO_FONT    *font8 = al_create_builtin_font();
     if( !okno )
    {
        fprintf( stderr, "Nie udalo sie stworzyc okna aplikacji :( \n" );
        return - 1;
    }

    // Tlo aplikacji
    al_clear_to_color( al_map_rgb( 20, 100, 150 ) );
    al_flip_display();


  int i, j, x, y, w;

  scanf("%d %d", &n,&m);
//-----------------------------------------------------------------------------------
/*                       !!! tablica dynamiczna !!!
    int wier, col;
    int **tab;

    // Pobranie danych
    printf("Wiersze: ");
    scanf("%d", &wier);
    printf("\nKolumny: ");
    scanf("%d", &col);

    // Alokacja pamięci dla tablicy dwuwymiarowej
    tab=(int**)malloc(wier*sizeof(int*)); // alokacja pamieci dla wierszy
    for(int i=0; i<wier; i++)
        tab[i]=(int*)malloc(col*sizeof(int)); // alokacja pamieci dla kolumn
 */
//------------------------------------------------------------------------------------



  for( i = 0; i < n; i++ )
  {

    for( j = 0; j < n; j++ )
    {
      tab [ i ][ j ] = MAXINT; // PRZYPISUJEMY NAJWIEKSZA WARTOSC
      tab_2 [ i ][ j ] = -1;     // TAB_2 WYPELNIAMY LICZBAMI -1
    }
    tab [ i ][ i ] = 0;        // DO PRZEKATNEJ TAB WPISUJEMY 0
  }

  for( i = 0; i < m; i++ )
  {
    scanf("%d %d %d", &x,&y, &w);// POBIERANIE WARTOSCI KRAWEDZI ???


/*                       KONTROLA CYKLI UJEMNYCH
    if(x==y && w<0) printf("graf nie może zawierac cykli ujemnych"); ???
 */


    tab [ x ][ y ] = w;        // W MACIERZY TAB UMIESZCZONA JEST WAGA KRAWEDZI ???
    tab_2 [ x ][ y ] = x;      // POPRZEDNIKIEM JEST X ORAZ Y
  }

  // WYWOLYWANIE PROGRAMU


  if( FloydWarshall( ) )
  {
    // WYSWIETLENIE WYNIKOW
    for( i = 0; i < n; i++ )
      for( j = 0; j < n; j++ )
      {
        printf("tab{%d ; %d] ", i, j);
        al_draw_textf(font8,al_map_rgb(255,255,0), 10, 10, 0,"tab{%3d ; %3d] ", i, j);
        printf("droga { ");
        FWPath ( i, j );
        printf("}");
        if( tab[ i ][ j ] < MAXINT )  printf ("\n koszt %d",tab [ i ][ j ]);
        printf("\n");
      }
  }
printf ( "Negative cycle found" );


    //Zwalnianie pamieci
    al_destroy_display( okno );

  return 0;
}
